import React from 'react';

export default function JokeSetup() {
  return(<div>JokeSetup goes here</div>)
};