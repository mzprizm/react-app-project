import React from 'react';

export default function JokePunchline() {
  return(<div>JokePunchline goes here</div>)
};